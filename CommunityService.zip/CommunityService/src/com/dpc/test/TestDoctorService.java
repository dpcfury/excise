package com.dpc.test;

import com.dpc.dao.DoctorUserDao;
import com.dpc.dao.impl.DoctorUserDaoImpl;
import com.dpc.pojo.Doctor;


public class TestDoctorService {

	
	public static void main(String[] args) {
		DoctorUserDao doctorService=new DoctorUserDaoImpl();
		
//		System.out.println(doctorService.checkDoctor("dpc", "123456"));
		
//		Doctor doctor =new Doctor();
//		doctor.setID("1");
//		doctor.setUserName("dpc");
//		doctor.setPassword("123456789");
//		doctor.setRealName("du");
//		doctor.setAge(21);
//		doctor.setSex("man");
//		doctor.setAddress("america,california");
//		doctor.setPhoneNum("15606135595");
//		
//		doctorService.updateInfo(doctor);
		
//		System.out.println(doctorService.getAllUsers());
//		
	}
}
